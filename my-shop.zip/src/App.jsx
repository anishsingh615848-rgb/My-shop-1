import React, { useState } from "react";

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  const addProduct = () => {
    if (!name || !price) return;
    setProducts([...products, { id: Date.now(), name, price: Number(price) }]);
    setName(""); setPrice("");
  };

  const total = cart.reduce((s, i) => s + i.price, 0);

  const payNow = () => {
    const options = {
      key: "YOUR_RAZORPAY_KEY_ID",
      amount: total * 100,
      currency: "INR",
      name: "My Shop",
      handler: function (res) {
        alert("Payment Success: " + res.razorpay_payment_id);
      }
    };
    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  return (
    <div style={{padding:20}}>
      <h1>My Shop</h1>

      <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
      <input placeholder="Price" value={price} onChange={e=>setPrice(e.target.value)} />
      <button onClick={addProduct}>Add</button>

      <h2>Products</h2>
      {products.map(p => (
        <div key={p.id}>
          {p.name} - ₹{p.price}
          <button onClick={()=>setCart([...cart, p])}>Add to Cart</button>
        </div>
      ))}

      <h2>Cart</h2>
      {cart.map((c,i)=><div key={i}>{c.name}</div>)}
      <h3>Total: ₹{total}</h3>

      <button onClick={payNow}>Pay Now</button>
    </div>
  );
}
